package com.example.gamesentry

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gamesentry.adapter.NewsAdapter
import com.example.gamesentry.model.News
import com.google.android.material.bottomnavigation.BottomNavigationView

class NewsActivity : AppCompatActivity() {

    private lateinit var newsRecyclerView: RecyclerView
    private lateinit var newsAdapter: NewsAdapter
    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)

        newsRecyclerView = findViewById(R.id.newsRecyclerView)
        bottomNav = findViewById(R.id.bottomNav)

        val newsList = generateDummyNews()

        // Kirim onItemClick ke adapter
        newsAdapter = NewsAdapter(newsList) { selectedNews ->
            val intent = Intent(this, NewsDetailActivity::class.java)
            intent.putExtra("title", selectedNews.title)
            intent.putExtra("source", selectedNews.source)
            intent.putExtra("time", selectedNews.time)
            intent.putExtra("imageUrl", selectedNews.imageUrl)
            intent.putExtra("tag", selectedNews.tag)
            intent.putExtra("content", selectedNews.content)
            startActivity(intent)
        }

        newsRecyclerView.layoutManager = LinearLayoutManager(this)
        newsRecyclerView.adapter = newsAdapter

        showData(newsList)
        setupBottomNavigation()
    }

    private fun showData(newsList: List<News>) {
        val emptyStateLayout = findViewById<LinearLayout>(R.id.emptyStateLayout)
        if (newsList.isEmpty()) {
            newsRecyclerView.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
        } else {
            newsRecyclerView.visibility = View.VISIBLE
            emptyStateLayout.visibility = View.GONE
            newsAdapter.updateList(newsList)
        }
    }

    private fun generateDummyNews(): List<News> {
        return listOf(
            News(
                title = "Game Terbaru Rilis Hari Ini!",
                source = "GameSentry News",
                time = "2 jam lalu",
                imageUrl = R.drawable.news1,
                tag = "Rilis",
                content = "Game terbaru dari developer terkenal akhirnya dirilis. Banyak fitur menarik yang ditambahkan."
            ),
            News(
                title = "Turnamen Esports Dunia 2025",
                source = "Esports Update",
                time = "5 jam lalu",
                imageUrl = R.drawable.news2,
                tag = "Esports",
                content = "Turnamen esports terbesar tahun ini akan digelar di Jakarta dengan hadiah miliaran rupiah."
            ),
            News(
                title = "Tips Naik Rank di Mobile Game",
                source = "Pro Player ID",
                time = "1 hari lalu",
                imageUrl = R.drawable.news3,
                tag = "Tips",
                content = "Berikut tips dan trik agar kamu bisa naik rank dengan cepat dan konsisten."
            )
        )
    }

    private fun setupBottomNavigation() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_news -> {
                    true // Halaman ini
                }
                R.id.nav_events -> {
                    startActivity(Intent(this, EventActivity::class.java))
                    true
                }
                R.id.nav_notifications -> {
                    startActivity(Intent(this, NotificationActivity::class.java))
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, AccountActivity::class.java))
                    true
                }
                else -> false
            }
        }
        bottomNav.selectedItemId = R.id.nav_news
    }
}