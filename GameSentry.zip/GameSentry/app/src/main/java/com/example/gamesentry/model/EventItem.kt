package com.example.gamesentry.model

data class EventItem(
    val title: String,
    val source: String,
    val time: String,
    val imageUrl: String
)