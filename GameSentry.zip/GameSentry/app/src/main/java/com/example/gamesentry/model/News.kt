package com.example.gamesentry.model

data class News(
    val title: String,
    val source: String,
    val time: String,
    val imageUrl: Int,
    val tag: String,
    val content: String
)

