package com.example.gamesentry.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.gamesentry.databinding.ItemEventBinding
import com.example.gamesentry.model.EventItem

class EventAdapter(
    private val eventList: List<EventItem>,
    private val onClick: (EventItem) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    inner class EventViewHolder(val binding: ItemEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: EventItem) {
            binding.textTitle.text = item.title
            binding.textSource.text = item.source
            binding.textTime.text = item.time

            // Load image from URL using Glide
            Glide.with(binding.root.context)
                .load(item.imageUrl)
                .into(binding.imageEvent)

            binding.root.setOnClickListener {
                onClick(item)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemEventBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = eventList[position]
        holder.bind(event)
    }

    override fun getItemCount(): Int = eventList.size
}