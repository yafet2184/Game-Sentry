package com.example.gamesentry.model

data class TrendingItem(
    val id: Int,
    val title: String,
    val category: String,
    val imageUrl: String,
    val time: String
)