package com.example.gamesentry

import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.LayoutInflater
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ChangePasswordActivity : AppCompatActivity() {

    private lateinit var btnBack: ImageView
    private lateinit var etCurrentPassword: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSavePassword: Button

    private lateinit var ivToggleCurrent: ImageView
    private lateinit var ivToggleNew: ImageView
    private lateinit var ivToggleConfirm: ImageView

    private var isCurrentVisible = false
    private var isNewVisible = false
    private var isConfirmVisible = false

    private lateinit var sharedPref: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        initViews()
        setupListeners()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        etCurrentPassword = findViewById(R.id.etCurrentPassword)
        etNewPassword = findViewById(R.id.etNewPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnSavePassword = findViewById(R.id.btnSavePassword)

        ivToggleCurrent = findViewById(R.id.ivToggleCurrent)
        ivToggleNew = findViewById(R.id.ivToggleNew)
        ivToggleConfirm = findViewById(R.id.ivToggleConfirm)

        sharedPref = getSharedPreferences("UserProfile", MODE_PRIVATE)

        hidePassword(etCurrentPassword)
        hidePassword(etNewPassword)
        hidePassword(etConfirmPassword)
    }

    private fun setupListeners() {
        btnBack.setOnClickListener {
            finish()
        }

        btnSavePassword.setOnClickListener {
            changePassword()
        }

        ivToggleCurrent.setOnClickListener {
            togglePasswordVisibility(etCurrentPassword, ivToggleCurrent)
        }

        ivToggleNew.setOnClickListener {
            togglePasswordVisibility(etNewPassword, ivToggleNew)
        }

        ivToggleConfirm.setOnClickListener {
            togglePasswordVisibility(etConfirmPassword, ivToggleConfirm)
        }
    }

    private fun changePassword() {
        val currentPasswordInput = etCurrentPassword.text.toString().trim()
        val newPasswordInput = etNewPassword.text.toString().trim()
        val confirmPasswordInput = etConfirmPassword.text.toString().trim()

        val savedPassword = sharedPref.getString("PASSWORD", "")

        when {
            currentPasswordInput.isEmpty() -> {
                shakeView(etCurrentPassword)
                etCurrentPassword.error = "Please enter your current password"
            }
            newPasswordInput.isEmpty() -> {
                shakeView(etNewPassword)
                etNewPassword.error = "Please enter new password"
            }
            confirmPasswordInput.isEmpty() -> {
                shakeView(etConfirmPassword)
                etConfirmPassword.error = "Please confirm new password"
            }
            currentPasswordInput != savedPassword -> {
                shakeView(etCurrentPassword)
                etCurrentPassword.error = "Current password is incorrect"
            }
            newPasswordInput.length < 6 -> {
                shakeView(etNewPassword)
                etNewPassword.error = "Password must be at least 6 characters"
            }
            !newPasswordInput.matches(Regex("^(?=.*[a-zA-Z])(?=.*[0-9]).+$")) -> {
                shakeView(etNewPassword)
                etNewPassword.error = "Password must contain letters and numbers"
            }
            newPasswordInput != confirmPasswordInput -> {
                shakeView(etConfirmPassword)
                etConfirmPassword.error = "Passwords do not match"
            }
            else -> {
                val editor = sharedPref.edit()
                editor.putString("PASSWORD", newPasswordInput)
                editor.apply()

                showCustomToast("Password changed successfully!", true)
                finish()
            }
        }
    }

    private fun togglePasswordVisibility(editText: EditText, toggleIcon: ImageView) {
        if (editText.transformationMethod is PasswordTransformationMethod) {
            editText.transformationMethod = HideReturnsTransformationMethod.getInstance()
            toggleIcon.setImageResource(R.drawable.ic_eye_open)
        } else {
            editText.transformationMethod = PasswordTransformationMethod.getInstance()
            toggleIcon.setImageResource(R.drawable.ic_eye_closed)
        }
        editText.setSelection(editText.text.length)
    }

    private fun hidePassword(editText: EditText) {
        editText.transformationMethod = PasswordTransformationMethod.getInstance()
    }

    private fun shakeView(view: View) {
        val shake = AnimationUtils.loadAnimation(this, R.anim.shake_animation)
        view.startAnimation(shake)
    }

    private fun showCustomToast(message: String, isSuccess: Boolean) {
        val inflater: LayoutInflater = layoutInflater
        val layout = inflater.inflate(R.layout.custom_toast, findViewById(R.id.toast_container))

        val tvToastMessage = layout.findViewById<TextView>(R.id.tvToastMessage)
        val ivToastIcon = layout.findViewById<ImageView>(R.id.ivToastIcon)

        tvToastMessage.text = message

        if (isSuccess) {
            ivToastIcon.setImageResource(R.drawable.ic_success)
        } else {
            ivToastIcon.setImageResource(R.drawable.ic_error)
        }

        val toast = Toast(this)
        toast.duration = Toast.LENGTH_SHORT
        toast.view = layout
        toast.show()
    }
}