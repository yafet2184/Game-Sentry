package com.example.gamesentry

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashScreenActivity : AppCompatActivity() {

    private val splashTime: Long = 3000 // 3 detik

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val backgroundStars = findViewById<ImageView>(R.id.backgroundStars)
        val logoImage = findViewById<ImageView>(R.id.logoImage)
        val appName = findViewById<TextView>(R.id.appName)

        // Load Animations
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        val scaleUp = AnimationUtils.loadAnimation(this, R.anim.scale_up)
        val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
        val moveBackground = AnimationUtils.loadAnimation(this, R.anim.move_background)

        // Start Animations
        backgroundStars.startAnimation(moveBackground)
        logoImage.startAnimation(scaleUp)
        appName.startAnimation(fadeIn)

        // After 1 second, shake logo
        Handler(Looper.getMainLooper()).postDelayed({
            logoImage.startAnimation(shake)
        }, 1000)

        // After splashTime, move to Sign Up
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
            finish()
        }, splashTime)
    }
}