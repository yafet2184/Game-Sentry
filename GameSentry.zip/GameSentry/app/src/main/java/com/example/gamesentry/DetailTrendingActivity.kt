package com.example.gamesentry

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.gamesentry.databinding.ActivityDetailTrendingBinding

class DetailTrendingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailTrendingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailTrendingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val title = intent.getStringExtra("title")
        val category = intent.getStringExtra("category")
        val imageUrl = intent.getStringExtra("imageUrl")

        binding.tvTitle.text = title
        binding.tvCategory.text = category

        Glide.with(this)
            .load(imageUrl)
            .placeholder(R.drawable.placeholder_image) // opsional
            .error(R.drawable.ic_error)             // opsional
            .into(binding.imgTrending)
    }
}