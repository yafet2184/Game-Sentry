package com.example.gamesentry.model

data class NotificationItem(
    val title: String,
    val message: String,
    val iconResId: Int
)