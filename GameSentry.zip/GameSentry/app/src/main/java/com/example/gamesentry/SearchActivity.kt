package com.example.gamesentry

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gamesentry.adapter.NewsAdapter
import com.example.gamesentry.databinding.ActivitySearchBinding
import com.example.gamesentry.model.News

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private lateinit var allNews: List<News>
    private lateinit var filteredNews: List<News>
    private lateinit var adapter: NewsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupSearchListener()
        setupBottomNavigation()
    }

    private fun setupRecyclerView() {
        allNews = getDummyNews()
        filteredNews = allNews
        adapter = NewsAdapter(filteredNews) { selectedNews ->
            val intent = Intent(this, NewsDetailActivity::class.java)
            intent.putExtra("title", selectedNews.title)
            intent.putExtra("source", selectedNews.source)
            intent.putExtra("time", selectedNews.time)
            intent.putExtra("imageUrl", selectedNews.imageUrl)
            intent.putExtra("tag", selectedNews.tag)
            intent.putExtra("content", selectedNews.content)
            startActivity(intent)
        }

        binding.rvNews.layoutManager = LinearLayoutManager(this)
        binding.rvNews.adapter = adapter
    }

    private fun setupSearchListener() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val query = s.toString().lowercase()
                filteredNews = allNews.filter {
                    it.title.lowercase().contains(query)
                }
                adapter.updateList(filteredNews)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupBottomNavigation() {
        binding.navHome.setOnClickListener {
            val intent = Intent(this, NewsActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.navSearch.setOnClickListener {
            // Sudah di halaman ini, tidak perlu aksi
        }

        binding.navAdd.setOnClickListener {
            val intent = Intent(this, AddNewsActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.navAccount.setOnClickListener {
            val intent = Intent(this, AccountActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun getDummyNews(): List<News> {
        return listOf(
            News("Cyberpunk 2077 Expansion", "IGN", "2h ago", R.drawable.news1, "RPG", "Expansion detail..."),
            News("Starfield Major Update", "GameSpot", "5h ago", R.drawable.news2, "Sci-Fi", "Update info..."),
            News("GTA 6 Leak", "Polygon", "1d ago", R.drawable.news3, "Open World", "Leak details...")
        )
    }
}