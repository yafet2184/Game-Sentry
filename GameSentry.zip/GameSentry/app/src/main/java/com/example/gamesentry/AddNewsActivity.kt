package com.example.gamesentry

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddNewsActivity : AppCompatActivity() {

    private lateinit var etTitle: EditText
    private lateinit var etContent: EditText
    private lateinit var etTag: EditText
    private lateinit var btnUpload: Button
    private lateinit var imagePreview: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_news)

        etTitle = findViewById(R.id.etTitle)
        etContent = findViewById(R.id.etContent)
        etTag = findViewById(R.id.etTag)
        btnUpload = findViewById(R.id.btnUploadNews)
        imagePreview = findViewById(R.id.ivThumbnail)

        btnUpload.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val content = etContent.text.toString().trim()
            val tag = etTag.text.toString().trim()

            if (title.isEmpty() || content.isEmpty() || tag.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Sementara hanya tampilkan data input
                Toast.makeText(this, "News Added:\n$title\n$tag", Toast.LENGTH_LONG).show()
            }
        }

        imagePreview.setOnClickListener {
            Toast.makeText(this, "Image picker coming soon!", Toast.LENGTH_SHORT).show()
        }
    }
}