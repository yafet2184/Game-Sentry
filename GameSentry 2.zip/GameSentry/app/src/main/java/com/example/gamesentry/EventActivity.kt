package com.example.gamesentry

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gamesentry.adapter.EventAdapter
import com.example.gamesentry.databinding.ActivityEventBinding
import com.example.gamesentry.model.EventItem

class EventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEventBinding
    private lateinit var eventAdapter: EventAdapter
    private val eventList = mutableListOf<EventItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupFilterButtons()
        setupBottomNavigation()
        loadDummyData()
    }

    private fun setupRecyclerView() {
        eventAdapter = EventAdapter(eventList) { selectedEvent ->
            val intent = Intent(this, EventDetailActivity::class.java).apply {
                putExtra("EVENT_TITLE", selectedEvent.title)
                putExtra("EVENT_IMAGE", selectedEvent.imageUrl)
                putExtra("EVENT_SOURCE", selectedEvent.source)
                putExtra("EVENT_TIME", selectedEvent.time)
            }
            startActivity(intent)
        }

        binding.rvEvents.apply {
            layoutManager = LinearLayoutManager(this@EventActivity)
            adapter = eventAdapter
        }
    }

    private fun loadDummyData() {
        eventList.clear()

        eventList.addAll(
            listOf(
                EventItem(
                    "Daftar game Esports World Cup 2025",
                    "ONE Esports ID",
                    "1 hours ago",
                    "https://dummyimage.com/600x400/000/fff&text=Esports+World+Cup"
                ),
                EventItem(
                    "PMGO 2025 Main Event Resmi Dimulai: Prediksi, Jadwal dan Cara Menonton",
                    "Liggagame Esports",
                    "1 hours ago",
                    "https://dummyimage.com/600x400/00f/fff&text=PMGO+2025"
                ),
                EventItem(
                    "Clash Royale Maret 2025, Ada Event, Hadiah, dan Tantangan Baru",
                    "Technologue ID",
                    "7 hours ago",
                    "https://dummyimage.com/600x400/f0f/fff&text=Clash+Royale"
                ),
                EventItem(
                    "Jadwal Turnamen Esports PUBG Mobile 2025, Jangan Lewatkan!",
                    "IDN Times",
                    "10 hours ago",
                    "https://dummyimage.com/600x400/f33/fff&text=PUBG+Event"
                )
            )
        )

        eventAdapter.notifyDataSetChanged()
        showEmptyState(eventList.isEmpty())
    }

    private fun showEmptyState(isEmpty: Boolean) {
        binding.emptyStateLayout.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvEvents.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun setupFilterButtons() {
        binding.btnTerupdate.setOnClickListener {
            // Tambahkan logika filter jika perlu
        }

        binding.btnEvent.setOnClickListener {
            // Sudah di Event
        }

        binding.btnTrending.setOnClickListener {
            startActivity(Intent(this, TrendingActivity::class.java))
            finish()
        }
    }

    private fun setupBottomNavigation() {
        val bottomNav = binding.root.findViewById<View>(R.id.bottomNavBar)

        val navNews = bottomNav.findViewById<View>(R.id.navNews)
        val navExplore = bottomNav.findViewById<View>(R.id.navExplore)
        val navAdd = bottomNav.findViewById<View>(R.id.navAdd)
        val navProfile = bottomNav.findViewById<View>(R.id.navProfile)

        navNews.setOnClickListener {
            updateNavSelection(navNews, listOf(navNews, navExplore, navAdd, navProfile))
            startActivity(Intent(this, NewsActivity::class.java))
            finish()
        }

        navExplore.setOnClickListener {
            updateNavSelection(navExplore, listOf(navNews, navExplore, navAdd, navProfile))
            startActivity(Intent(this, SearchActivity::class.java))
            finish()
        }

        navAdd.setOnClickListener {
            updateNavSelection(navAdd, listOf(navNews, navExplore, navAdd, navProfile))
            startActivity(Intent(this, AddNewsActivity::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            updateNavSelection(navProfile, listOf(navNews, navExplore, navAdd, navProfile))
            startActivity(Intent(this, AccountActivity::class.java))
            finish()
        }

        // Highlight default (misalnya News)
        updateNavSelection(navNews, listOf(navNews, navExplore, navAdd, navProfile))
    }

    private fun updateNavSelection(selectedView: View, navIcons: List<View>) {
        navIcons.forEach { it.isSelected = (it == selectedView) }
    }
}