package com.example.gamesentry

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.*

class EditProfileActivity : AppCompatActivity() {

    private lateinit var ivProfilePicture: ImageView
    private lateinit var etName: EditText
    private lateinit var etUsername: EditText
    private lateinit var etEmail: EditText
    private lateinit var etDateOfBirth: EditText
    private lateinit var rgGender: RadioGroup
    private lateinit var rbMale: RadioButton
    private lateinit var rbFemale: RadioButton
    private lateinit var btnSave: Button

    private var selectedImageUri: String? = null
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        initViews()
        loadProfileData()
        setupListeners()
    }

    private fun initViews() {
        ivProfilePicture = findViewById(R.id.ivProfilePicture)
        etName = findViewById(R.id.etName)
        etUsername = findViewById(R.id.etUsername)
        etEmail = findViewById(R.id.etEmail)
        etDateOfBirth = findViewById(R.id.etDateOfBirth)
        rgGender = findViewById(R.id.rgGender)
        rbMale = findViewById(R.id.rbMale)
        rbFemale = findViewById(R.id.rbFemale)
        btnSave = findViewById(R.id.btnSave)
    }

    private fun loadProfileData() {
        val sharedPref = getSharedPreferences("UserProfile", MODE_PRIVATE)

        val name = sharedPref.getString("NAME", "")
        val username = sharedPref.getString("USERNAME", "")
        val email = sharedPref.getString("EMAIL", "")
        val dob = sharedPref.getString("DOB", "")
        val gender = sharedPref.getString("GENDER", "")
        val profilePicture = sharedPref.getString("PROFILE_PICTURE", null)

        etName.setText(name)
        etUsername.setText(username)
        etEmail.setText(email)
        etDateOfBirth.setText(dob)

        when (gender) {
            "Male" -> rbMale.isChecked = true
            "Female" -> rbFemale.isChecked = true
        }

        if (!profilePicture.isNullOrEmpty()) {
            selectedImageUri = profilePicture
            Glide.with(this)
                .load(profilePicture)
                .centerCrop()
                .into(ivProfilePicture)
        }
    }

    private fun setupListeners() {
        ivProfilePicture.setOnClickListener {
            pickImageFromGallery()
        }

        etDateOfBirth.setOnClickListener {
            showDatePickerDialog()
        }

        btnSave.setOnClickListener {
            validateAndSave()
        }
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_PICK_IMAGE)
    }

    private fun showDatePickerDialog() {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePicker = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            calendar.set(selectedYear, selectedMonth, selectedDay)
            val format = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            etDateOfBirth.setText(format.format(calendar.time))
        }, year, month, day)

        datePicker.show()
    }

    private fun validateAndSave() {
        val name = etName.text.toString().trim()
        val username = etUsername.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val dateOfBirth = etDateOfBirth.text.toString().trim()
        val genderId = rgGender.checkedRadioButtonId

        when {
            name.isEmpty() -> etName.error = "Please enter your name"
            username.isEmpty() -> etUsername.error = "Please enter your username"
            email.isEmpty() -> etEmail.error = "Please enter your email"
            dateOfBirth.isEmpty() -> etDateOfBirth.error = "Please select your date of birth"
            genderId == -1 -> Toast.makeText(this, "Please select your gender", Toast.LENGTH_SHORT).show()
            else -> {
                saveProfile(name, username, email, dateOfBirth, genderId)
                Toast.makeText(this, "Profile saved successfully!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun saveProfile(name: String, username: String, email: String, dob: String, genderId: Int) {
        val gender = if (genderId == R.id.rbMale) "Male" else "Female"

        val sharedPref = getSharedPreferences("UserProfile", MODE_PRIVATE)
        val editor = sharedPref.edit()
        editor.putString("NAME", name)
        editor.putString("USERNAME", username)
        editor.putString("EMAIL", email)
        editor.putString("DOB", dob)
        editor.putString("GENDER", gender)
        selectedImageUri?.let {
            editor.putString("PROFILE_PICTURE", it)
        }
        editor.apply()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            val imageUri = data.data
            selectedImageUri = imageUri.toString()
            Glide.with(this)
                .load(imageUri)
                .centerCrop()
                .into(ivProfilePicture)
        }
    }

    companion object {
        private const val REQUEST_PICK_IMAGE = 1001
    }
}