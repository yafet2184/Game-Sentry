package com.example.gamesentry

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gamesentry.adapter.TrendingAdapter
import com.example.gamesentry.model.TrendingItem

class TrendingActivity : AppCompatActivity() {

    private lateinit var trendingRecyclerView: RecyclerView
    private lateinit var emptyStateLayoutTrending: View
    private lateinit var trendingAdapter: TrendingAdapter
    private lateinit var trendingList: ArrayList<TrendingItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trending)

        trendingRecyclerView = findViewById(R.id.rvTrendingRecyclerView)
        emptyStateLayoutTrending = findViewById(R.id.emptyStateLayoutTrending)

        trendingRecyclerView.layoutManager = LinearLayoutManager(this)

        trendingList = loadTrendingData()
        trendingAdapter = TrendingAdapter(trendingList)
        trendingRecyclerView.adapter = trendingAdapter

        showTrendingData(trendingList)
    }

    private fun loadTrendingData(): ArrayList<TrendingItem> {
        return arrayListOf(
            TrendingItem(
                id = 1,
                title = "Tujuh Kode Redeem Mobile Legends Moonton Terbaru 2025",
                category = "Mobile Legends",
                imageUrl = "https://i.ibb.co/mGTXdsP/mlbb.jpg",
                time = "2 jam yang lalu"
            ),
            TrendingItem(
                id = 2,
                title = "Update Besar PUBG Mobile 2025",
                category = "PUBG",
                imageUrl = "https://i.ibb.co/tPgcxP6/pubg.jpg",
                time = "4 jam yang lalu"
            ),
            TrendingItem(
                id = 3,
                title = "Valorant Hadirkan Map Baru Tahun Ini",
                category = "Valorant",
                imageUrl = "https://i.ibb.co/5Lxq4L7/valorant.jpg",
                time = "6 jam yang lalu"
            ),
            TrendingItem(
                id = 4,
                title = "Free Fire Hadirkan Mode Zombie",
                category = "Free Fire",
                imageUrl = "https://i.ibb.co/yp7zjXV/freefire.jpg",
                time = "8 jam yang lalu"
            )
        )
    }

    private fun showTrendingData(trendingList: List<TrendingItem>) {
        if (trendingList.isEmpty()) {
            trendingRecyclerView.visibility = View.GONE
            emptyStateLayoutTrending.visibility = View.VISIBLE
        } else {
            trendingRecyclerView.visibility = View.VISIBLE
            emptyStateLayoutTrending.visibility = View.GONE
        }
    }
}