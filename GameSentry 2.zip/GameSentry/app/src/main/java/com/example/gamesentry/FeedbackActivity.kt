package com.example.gamesentry

import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gamesentry.databinding.ActivityFeedbackBinding

class FeedbackActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFeedbackBinding
    private var selectedRating: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val faces = listOf(
            binding.face1, binding.face2, binding.face3,
            binding.face4, binding.face5
        )

        // Handle pemilihan emoji
        faces.forEachIndexed { index, imageView ->
            imageView.setOnClickListener {
                selectedRating = index
                updateSelection(faces, index)
            }
        }

        // Tombol kembali
        binding.btnBack.setOnClickListener {
            finish()
        }

        // Submit feedback
        binding.btnSubmit.setOnClickListener {
            if (selectedRating != -1) {
                Toast.makeText(
                    this,
                    "Feedback dikirim: ${getFeedbackText(selectedRating)}",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, "Silakan pilih rating terlebih dahulu.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateSelection(faces: List<ImageView>, selectedIndex: Int) {
        faces.forEachIndexed { index, imageView ->
            imageView.alpha = if (index == selectedIndex) 1.0f else 0.5f
        }
    }

    private fun getFeedbackText(index: Int): String {
        return when (index) {
            0 -> "No Way!"
            1 -> "Poor"
            2 -> "OK"
            3 -> "Very Good"
            4 -> "Love It!"
            else -> ""
        }
    }
}