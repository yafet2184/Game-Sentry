package com.example.gamesentry

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.gamesentry.ui.*

class AccountActivity : AppCompatActivity() {

    private lateinit var btnBack: ImageView
    private lateinit var btnLogout: Button

    // Menu buttons (pakai LinearLayout karena include layout)
    private lateinit var btnEditProfile: View
    private lateinit var btnChangePassword: View
    private lateinit var btnNotification: View
    private lateinit var btnFeedback: View
    private lateinit var btnAbout: View

    // Bottom navigation
    private lateinit var navNews: ImageView
    private lateinit var navSearch: ImageView
    private lateinit var navAdd: ImageView
    private lateinit var navAccount: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account)

        initViews()
        setupListeners()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        btnLogout = findViewById(R.id.btnLogout)

        btnEditProfile = findViewById(R.id.btnEditProfile)
        btnChangePassword = findViewById(R.id.btnChangePassword)
        btnNotification = findViewById(R.id.btnNotification)
        btnFeedback = findViewById(R.id.btnFeedback)
        btnAbout = findViewById(R.id.btnAbout)

        navNews = findViewById(R.id.navNews)
        navSearch = findViewById(R.id.navSearch)
        navAdd = findViewById(R.id.navAdd)
        navAccount = findViewById(R.id.navAccount)
    }

    private fun setupListeners() {

        // Set text untuk masing-masing menu
        btnEditProfile.findViewById<TextView>(R.id.tvLabel).text = "Edit Profile"
        btnChangePassword.findViewById<TextView>(R.id.tvLabel).text = "Change Password"
        btnNotification.findViewById<TextView>(R.id.tvLabel).text = "Notification"
        btnFeedback.findViewById<TextView>(R.id.tvLabel).text = "Feedback"
        btnAbout.findViewById<TextView>(R.id.tvLabel).text = "About"

        (findViewById<View>(R.id.btnEditProfile).findViewById<TextView>(R.id.tvLabel)).text = "Edit Profile"
        (findViewById<View>(R.id.btnChangePassword).findViewById<TextView>(R.id.tvLabel)).text = "Change Password"
        (findViewById<View>(R.id.btnNotification).findViewById<TextView>(R.id.tvLabel)).text = "Notification"
        (findViewById<View>(R.id.btnFeedback).findViewById<TextView>(R.id.tvLabel)).text = "Feedback"
        (findViewById<View>(R.id.btnAbout).findViewById<TextView>(R.id.tvLabel)).text = "About"

        btnBack.setOnClickListener { finish() }

        btnLogout.setOnClickListener {
            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        btnEditProfile.setOnClickListener {
            Toast.makeText(this, "Edit Profile clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, EditProfileActivity::class.java))
        }

        btnChangePassword.setOnClickListener {
            Toast.makeText(this, "Change Password clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, ChangePasswordActivity::class.java))
        }

        btnNotification.setOnClickListener {
            startActivity(Intent(this, NotificationActivity::class.java))
        }

        btnFeedback.setOnClickListener {
            Toast.makeText(this, "Feedback clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, FeedbackActivity::class.java))
        }

        btnAbout.setOnClickListener {
            Toast.makeText(this, "About clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, AboutActivity::class.java))
        }

        navNews.setOnClickListener {
            startActivity(Intent(this, NewsActivity::class.java))
        }

        navSearch.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }

        navAdd.setOnClickListener {
            startActivity(Intent(this, AddNewsActivity::class.java))
        }

        navAccount.setOnClickListener {
            Toast.makeText(this, "Already in Account", Toast.LENGTH_SHORT).show()
        }
    }
}