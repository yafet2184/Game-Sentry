package com.example.gamesentry.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.gamesentry.NewsDetailActivity
import com.example.gamesentry.R
import com.example.gamesentry.model.News

class NewsAdapter(
    private var newsList: List<News>,
    private val onItemClick: (News) -> Unit
) : RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    inner class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumbnail: ImageView = itemView.findViewById(R.id.ivNewsThumbnail)
        val tvTitle: TextView = itemView.findViewById(R.id.tvNewsTitle)
        val tvSource: TextView = itemView.findViewById(R.id.tvNewsSource)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_news, parent, false)
        return NewsViewHolder(view)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        val news = newsList[position]

        with(holder) {
            tvTitle.text = news.title
            tvSource.text = "${news.source} • ${news.time}"

            Glide.with(itemView.context)
                .load(news.imageUrl)
                .into(ivThumbnail)

            itemView.setOnClickListener {
                val context = itemView.context
                onItemClick(news)
                val intent = Intent(context, NewsDetailActivity::class.java).apply {
                    putExtra("title", news.title)
                    putExtra("source", news.source)
                    putExtra("time", news.time)
                    putExtra("image", news.imageUrl)
                    putExtra("content", news.content)
                }
                context.startActivity(intent)
            }
        }
    }
        override fun getItemCount(): Int = newsList.size

        fun updateList(newList: List<News>) {
            newsList = newList
            notifyDataSetChanged()
        }
    }