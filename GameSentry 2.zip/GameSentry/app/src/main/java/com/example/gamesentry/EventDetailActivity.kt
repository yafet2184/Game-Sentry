package com.example.gamesentry

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.gamesentry.databinding.ActivityEventDetailBinding

class EventDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEventDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val title = intent.getStringExtra("title")
        val source = intent.getStringExtra("source")
        val time = intent.getStringExtra("time")
        val imageResId = intent.getIntExtra("image", R.drawable.ic_launcher_foreground)

        binding.tvEventDetailTitle.text = title
        binding.tvEventDetailSource.text = source
        binding.tvEventDetailTime.text = time
        binding.ivEventDetailImage.setImageResource(imageResId)

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}