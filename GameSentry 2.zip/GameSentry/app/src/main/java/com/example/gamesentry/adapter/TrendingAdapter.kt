package com.example.gamesentry.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.gamesentry.R
import com.example.gamesentry.model.TrendingItem
import com.example.gamesentry.DetailTrendingActivity

class TrendingAdapter(private val listTrending: List<TrendingItem>) :
    RecyclerView.Adapter<TrendingAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgTrending: ImageView = itemView.findViewById(R.id.trendingImage)
        val tvTitle: TextView = itemView.findViewById(R.id.trendingTitle)
        val tvSource: TextView = itemView.findViewById(R.id.trendingSource)
        val tvTime: TextView = itemView.findViewById(R.id.trendingTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_trending, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trending = listTrending[position]
        holder.tvTitle.text = trending.title
        holder.tvSource.text = trending.category // Dianggap category = source
        holder.tvTime.text = trending.time

        Glide.with(holder.itemView.context)
            .load(trending.imageUrl)
            .placeholder(R.drawable.placeholder_image)
            .error(R.drawable.ic_error)
            .into(holder.imgTrending)

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailTrendingActivity::class.java).apply {
                putExtra("title", trending.title)
                putExtra("category", trending.category)
                putExtra("imageUrl", trending.imageUrl)
                putExtra("time", trending.time)
            }
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = listTrending.size
}