package com.example.gamesentry.model

data class NewsItem(
    val title: String,
    val author: String,
    val time: String,
    val content: String,
    val timeAgo: String,
    val imageUrl: String,
    val tag: String,
    val source: String
)