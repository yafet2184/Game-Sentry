package com.example.gamesentry

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.gamesentry.adapter.NotificationAdapter
import com.example.gamesentry.model.NotificationItem

class NotificationActivity : AppCompatActivity() {

    private lateinit var rvNotification: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var btnBack: ImageView
    private lateinit var notificationAdapter: NotificationAdapter
    private lateinit var dummyNotifications: List<NotificationItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)

        // Inisialisasi view
        rvNotification = findViewById(R.id.rvNotification)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)
        btnBack = findViewById(R.id.btnBack)

        // Tombol kembali
        btnBack.setOnClickListener {
            finish()
        }

        // Dummy data (pastikan model NotificationItem sudah benar)
        dummyNotifications = listOf(
            NotificationItem(
                title = "Game Update Available!",
                message = "Check out the latest update for XYZ game.",
                iconResId = R.drawable.ic_notification
            ),
            NotificationItem(
                title = "Tournament Coming Soon!",
                message = "Join the upcoming gaming tournament.",
                iconResId = R.drawable.ic_notification
            ),
            NotificationItem(
                title = "New Feature Added",
                message = "We've added a new chat feature to the app!",
                iconResId = R.drawable.ic_notification
            )
        )

        // Setup RecyclerView
        notificationAdapter = NotificationAdapter(dummyNotifications)
        rvNotification.layoutManager = LinearLayoutManager(this)
        rvNotification.adapter = notificationAdapter

        // Swipe refresh simulasi
        swipeRefreshLayout.setOnRefreshListener {
            swipeRefreshLayout.isRefreshing = false
        }

        // Tampilkan empty state jika data kosong
        toggleEmptyState(dummyNotifications.isEmpty())
    }

    private fun toggleEmptyState(isEmpty: Boolean) {
        if (isEmpty) {
            emptyStateLayout.visibility = View.VISIBLE
            rvNotification.visibility = View.GONE
        } else {
            emptyStateLayout.visibility = View.GONE
            rvNotification.visibility = View.VISIBLE
        }
    }
}