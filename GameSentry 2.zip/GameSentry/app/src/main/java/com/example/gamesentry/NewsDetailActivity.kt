package com.example.gamesentry

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class NewsDetailActivity : AppCompatActivity() {

    private lateinit var ivNewsImage: ImageView
    private lateinit var tvNewsTitle: TextView
    private lateinit var tvNewsSourceTime: TextView
    private lateinit var tvNewsContent: TextView
    private lateinit var btnBack: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_detail)

        ivNewsImage = findViewById(R.id.ivNewsImage)
        tvNewsTitle = findViewById(R.id.tvNewsTitle)
        tvNewsSourceTime = findViewById(R.id.tvNewsSourceTime)
        tvNewsContent = findViewById(R.id.tvNewsContent)
        btnBack = findViewById(R.id.btnBack)

        // Ambil data dari intent
        val title = intent.getStringExtra("title")
        val source = intent.getStringExtra("source")
        val time = intent.getStringExtra("time")
        val imageResId = intent.getIntExtra("image", R.drawable.ic_launcher_background) // fallback
        val content = intent.getStringExtra("content")

        // Tampilkan datanya
        tvNewsTitle.text = title
        tvNewsSourceTime.text = "$source • $time"
        tvNewsContent.text = content

        Glide.with(this)
            .load(imageResId)
            .into(ivNewsImage)

        btnBack.setOnClickListener {
            onBackPressed()
        }
    }
}